# AXION Navigation v1

Nova navegação autenticada:

- sidebar esquerda;
- Dashboard;
- Detalhes;
- Relatórios;
- Configuração, conforme perfil;
- Usuários como item independente, somente Administrador;
- logo AXION no canto superior direito;
- logout compacto no canto superior direito;
- remove o conceito de menu Conta que abre "Usuários" e "Sair".

Integração no app.py:

1. Adicionar:
   `from ui.navigation import render_navigation`

2. Remover o bloco antigo `CABECALHO / NAVEGAÇÃO`, incluindo:
   - `brand_col, home_col, details_col, reports_col, config_col, account_col`
   - `show_account_menu`
   - `account_user_col`
   - `account_users_col`
   - `account_logout_col`

3. No lugar do bloco antigo, usar:
   `render_navigation(st.session_state.view, st.session_state.user_profile)`

Não altera autenticação nem dados.
