import base64
from pathlib import Path

import streamlit as st

from core.session import allowed_profiles, logout

ROOT = Path(__file__).resolve().parent.parent
ASSETS = ROOT / "assets"
AXION_LOGO = ASSETS / "axion-logo.png"


def _logo_data_uri() -> str:
    if not AXION_LOGO.exists():
        return ""
    encoded = base64.b64encode(AXION_LOGO.read_bytes()).decode("ascii")
    return f"data:image/png;base64,{encoded}"


def _set_view(view: str) -> None:
    st.session_state.view = view
    st.session_state.show_account_menu = False
    st.rerun()


def render_navigation(current_view: str, profile: dict | None = None) -> None:
    """
    Renderiza a navegação autenticada do AXION.

    Estrutura:
      - sidebar esquerda com navegação;
      - logo AXION no canto superior direito;
      - logout pequeno no canto superior direito;
      - Usuários como item próprio, somente para Administrador.

    Não altera a lógica das páginas; apenas atualiza `st.session_state.view`.
    """
    profile = profile or st.session_state.get("user_profile") or {}
    user_name = str(profile.get("nome") or profile.get("email") or "Usuário")
    user_role = str(profile.get("perfil") or "Operador")

    logo_uri = _logo_data_uri()

    st.markdown(
        """
<style>
/* ==========================================================
   AXION — NAVIGATION
   ========================================================== */

[data-testid="stSidebar"] {
    background: linear-gradient(180deg, #03101f 0%, #061a2d 100%);
    border-right: 1px solid rgba(25, 145, 255, .20);
}

[data-testid="stSidebar"] > div:first-child {
    background: transparent;
}

[data-testid="stSidebar"] [data-testid="stVerticalBlock"] {
    gap: .35rem;
}

.axion-side-brand {
    padding: 8px 6px 20px;
    border-bottom: 1px solid rgba(86, 145, 190, .18);
    margin-bottom: 14px;
}

.axion-side-brand-name {
    color: #ffffff;
    font-size: 22px;
    font-weight: 900;
    letter-spacing: .035em;
    line-height: 1;
}

.axion-side-brand-name span {
    color: #19a2ff;
}

.axion-side-brand-sub {
    margin-top: 7px;
    color: #9db3c8;
    font-size: 9px;
    font-weight: 750;
    letter-spacing: .12em;
    text-transform: uppercase;
}

.axion-side-section {
    color: #5fbfff;
    font-size: 9px;
    font-weight: 850;
    letter-spacing: .13em;
    text-transform: uppercase;
    margin: 6px 5px 7px;
}

.axion-side-user {
    margin: 16px 3px 4px;
    padding: 10px 10px 9px;
    border: 1px solid rgba(77, 139, 184, .22);
    border-radius: 10px;
    background: rgba(3, 16, 31, .40);
}

.axion-side-user-name {
    color: #edf6ff;
    font-size: 12px;
    font-weight: 800;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.axion-side-user-role {
    margin-top: 3px;
    color: #82a0b8;
    font-size: 9px;
    font-weight: 700;
}

/* Sidebar buttons */
[data-testid="stSidebar"] div.stButton > button {
    width: 100% !important;
    min-height: 40px !important;
    padding: .35rem .65rem !important;
    border: 1px solid transparent !important;
    border-radius: 9px !important;
    background: transparent !important;
    color: #c9d9e7 !important;
    box-shadow: none !important;
    text-align: left !important;
    font-size: .78rem !important;
    font-weight: 750 !important;
}

[data-testid="stSidebar"] div.stButton > button:hover {
    color: #ffffff !important;
    background: rgba(21, 159, 255, .10) !important;
    border-color: rgba(21, 159, 255, .18) !important;
}

[data-testid="stSidebar"] div.stButton > button[kind="primary"] {
    color: #ffffff !important;
    background: linear-gradient(
        90deg,
        rgba(7, 93, 242, .86),
        rgba(21, 159, 255, .72)
    ) !important;
    border-color: rgba(41, 164, 255, .70) !important;
    box-shadow: 0 6px 18px rgba(7, 105, 255, .16) !important;
}

[data-testid="stSidebar"] div.stButton > button p {
    color: inherit !important;
    font-weight: 750 !important;
}

/* Top-right controls */
.axion-topbar {
    min-height: 50px;
    margin-bottom: 8px;
    display: flex;
    align-items: center;
    justify-content: flex-end;
    gap: 10px;
}

.axion-topbar-logo {
    max-height: 34px;
    max-width: 150px;
    width: auto;
    object-fit: contain;
    display: block;
}

.axion-top-user {
    color: #8fa8bd;
    font-size: 10px;
    font-weight: 700;
    white-space: nowrap;
}

[data-testid="stMainBlockContainer"] {
    padding-top: .55rem !important;
}

/* Small logout button */
.axion-logout-wrap div.stButton > button {
    min-width: 34px !important;
    width: 34px !important;
    min-height: 32px !important;
    height: 32px !important;
    padding: 0 !important;
    border-radius: 8px !important;
    background: rgba(5, 19, 34, .72) !important;
    border: 1px solid rgba(99, 149, 186, .32) !important;
    color: #b7cadb !important;
    font-size: 16px !important;
}

.axion-logout-wrap div.stButton > button:hover {
    background: rgba(255, 91, 97, .13) !important;
    border-color: rgba(255, 91, 97, .45) !important;
    color: #ff8f95 !important;
}

@media (max-width: 900px) {
    .axion-top-user {
        display: none;
    }
}
</style>
""",
        unsafe_allow_html=True,
    )

    # ---------- sidebar ----------
    with st.sidebar:
        st.markdown(
            """
<div class="axion-side-brand">
  <div class="axion-side-brand-name">AX<span>ION</span></div>
  <div class="axion-side-brand-sub">Monitoramento Industrial</div>
</div>
<div class="axion-side-section">Navegação</div>
""",
            unsafe_allow_html=True,
        )

        if st.button(
            "⌂  Dashboard",
            key="nav_dashboard_sidebar",
            width="stretch",
            type="primary" if current_view == "dashboard" else "secondary",
        ):
            _set_view("dashboard")

        if st.button(
            "▣  Detalhes",
            key="nav_details_sidebar",
            width="stretch",
            type="primary" if current_view == "details" else "secondary",
        ):
            _set_view("details")

        if st.button(
            "▤  Relatórios",
            key="nav_reports_sidebar",
            width="stretch",
            type="primary" if current_view == "reports" else "secondary",
        ):
            _set_view("reports")

        if allowed_profiles("Administrador", "Gerente", "Técnico"):
            if st.button(
                "⚙  Configuração",
                key="nav_config_sidebar",
                width="stretch",
                type="primary" if current_view == "config" else "secondary",
            ):
                _set_view("config")

        if allowed_profiles("Administrador"):
            st.markdown(
                '<div class="axion-side-section" style="margin-top:16px;">Administração</div>',
                unsafe_allow_html=True,
            )
            if st.button(
                "●  Usuários",
                key="nav_users_sidebar",
                width="stretch",
                type="primary" if current_view == "users" else "secondary",
            ):
                _set_view("users")

        st.markdown(
            f"""
<div class="axion-side-user">
  <div class="axion-side-user-name">{user_name}</div>
  <div class="axion-side-user-role">{user_role}</div>
</div>
""",
            unsafe_allow_html=True,
        )

    # ---------- top-right ----------
    top_cols = st.columns([8.8, 1.8, .48], gap="small")

    with top_cols[0]:
        st.empty()

    with top_cols[1]:
        if logo_uri:
            st.markdown(
                f'<div class="axion-topbar"><img class="axion-topbar-logo" '
                f'src="{logo_uri}" alt="AXION"></div>',
                unsafe_allow_html=True,
            )
        else:
            st.markdown(
                '<div class="axion-topbar"><b style="color:#fff;">AXION</b></div>',
                unsafe_allow_html=True,
            )

    with top_cols[2]:
        st.markdown('<div class="axion-logout-wrap">', unsafe_allow_html=True)
        if st.button("⎋", key="top_logout", help="Sair"):
            logout()
        st.markdown("</div>", unsafe_allow_html=True)
